﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using Restaurantreviewz.Entities;
using Restaurantreviewz.Data;

namespace Restaurantreviewz.Services
{
    public class SqlRestaurantRepository : IRestaurantRepository
    {
        private readonly ApplicationDbContext _context;
        public SqlRestaurantRepository (ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task CommitAsync()
        {
            await _context.SaveChangesAsync();
        }

        public async Task<IEnumerable<Restaurant>> GetAllRestaurantsAsync()
        {
            return await _context.Restaurants.ToListAsync();
        }
        public async Task<Restaurant> GetRestaurantAsync(int id)
        {
            return await _context.Restaurants
                .SingleOrDefaultAsync(r => r.RestaurantId == id);
        }
        public async Task<Restaurant> GetRestaurantWithReviewsAsync(int id)
        {
            return await _context.Restaurants
                .Include(r => r.Reviews)
                .SingleOrDefaultAsync(r => r.RestaurantId == id);
        }

        public async Task<IEnumerable<Restaurant>> GetRestaurantByCityAsync(string city)
        {
            return await _context.Restaurants
                .Where(r => r.City.Contains(city))
                .ToListAsync();
        }
        public async Task<IEnumerable<Restaurant>> GetReviewandResrByUserAsync(string usename)
        {
            return await _context.Restaurants
                .Include(r => r.Reviews.Select(t => t.ReviewerName.Contains(usename))).ToListAsync();
        }
        public void CreateRestaurant(Restaurant restaurant)
        {
            _context.Add(restaurant);
        }

        public void UpdateRestaurant(Restaurant restaurant)
        {
            _context.Entry(restaurant).State = EntityState.Modified;
        }
        public async Task<Restaurant> DeleteRestaurantAsync(int id)
        {
            var restaurant = await GetRestaurantAsync(id);
            if (restaurant != null)
            {
                _context.Remove(restaurant);
            }
            return restaurant;
        }
        public async Task<bool> RestaurantExists(int id)
        {
            return await _context.Restaurants.AnyAsync(r => r.RestaurantId == id);
        }
        public async Task<bool> RestaurantExists(string name, string city)
        {
            return await _context.Restaurants
                    .AnyAsync(r => r.Name.ToLower() == name.ToLower() && r.City.ToLower() == city.ToLower());
        }

        //====== Review =============
        public async Task<IEnumerable<Review>> GetAllReviewsAsync()
        {
            return await _context.Reviews.ToListAsync();
        }

        public async Task<Review> GetReviewAsync(int id)
        {
            return await _context.Reviews
                .SingleOrDefaultAsync(r => r.ReviewId == id);
        }

        public async Task<IEnumerable<Review>> GetReviewByUserAsync(string usename)
        {
            return await _context.Reviews
                .Where(r => r.ReviewerName.Contains(usename))
                .ToListAsync();
        }

        public async Task<IEnumerable<Review>> GetReviewsPerRestaurantAsync(int restaurantId)
        {
            return await _context.Reviews
                .Where(r => r.RestaurantId == restaurantId)
                .ToListAsync();
        }
        //
        public void CreateReview(Review review)
        {
            _context.Add(review);
        }

        public void UpdateReview(Review review)
        {
            _context.Entry(review).State = EntityState.Modified;
        }

        public async Task<Review> DeleteReviewAsync(int id)
        {
            var review = await GetReviewAsync(id);
            if (review != null)
            {
                _context.Remove(review);
            }
            return review;
        }
        public Review DeleteReview(Review review)
        {
            if (review != null)
            {
                _context.Remove(review);
            }
            return review;
        }
        public async Task<bool> ReviewExists(int id)
        {
            return await _context.Reviews.AnyAsync(r => r.ReviewId == id);
        }
    }
}
