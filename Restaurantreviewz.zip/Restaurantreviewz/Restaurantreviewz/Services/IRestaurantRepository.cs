﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Restaurantreviewz.Entities;

namespace Restaurantreviewz.Services
{
    public interface IRestaurantRepository
    {
        Task<IEnumerable<Restaurant>> GetAllRestaurantsAsync();
        Task<Restaurant> GetRestaurantAsync(int id);
        Task<Restaurant> GetRestaurantWithReviewsAsync(int id);
        Task<IEnumerable<Restaurant>> GetRestaurantByCityAsync(string city);
        Task<IEnumerable<Restaurant>> GetReviewandResrByUserAsync(string usename);
        void CreateRestaurant(Restaurant restaurant);
        void UpdateRestaurant(Restaurant restaurant);
        Task<Restaurant> DeleteRestaurantAsync(int id);
        Task<bool> RestaurantExists(int id);
        Task<bool> RestaurantExists(string name, string city);

        Task<IEnumerable<Review>> GetAllReviewsAsync();
        Task<IEnumerable<Review>> GetReviewByUserAsync(string usename);
        Task<IEnumerable<Review>> GetReviewsPerRestaurantAsync(int restaurantId);
        Task<Review> GetReviewAsync(int id);
        void CreateReview(Review review);
        void UpdateReview(Review review);
        Task<Review> DeleteReviewAsync(int id);
        Review DeleteReview(Review review);
        Task<bool> ReviewExists(int id);

        Task CommitAsync();
    }
}
