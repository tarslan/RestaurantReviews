﻿(function () {
    var searchForm = document.querySelector("#searchForm");
    var retaurants = document.querySelector("#retaurants");
    var qstring = document.getElementById("search");
    var restaurantId = document.querySelector("#restaurantId");

    var reviewSearchForm = document.querySelector("#frmReviewSearch");
    var reviewsbyuser = document.querySelector("#reviewsbyuser");
    var searchReview = document.getElementById("searchReview");

    var $createReview = $("#createReview");
    var $cancel = $("#btnCancel");

    function getReviews(e) {
        e.preventDefault();
        var url = reviewSearchForm.getAttribute("action") + "?search=" + searchReview.value;
        //By default felch does GET
        fetch(url, {
            headers: new Headers({
                'Content-Type': 'application/xhtml+xml'
            })
        })
            .then(
            function (response) {
                if (response.status !== 200) {
                    console.log('Looks like there was a problem. Status Code: ' + response.status);
                    return;
                }
                // Examine the response  
                response.text().then(function (data) {
                    reviewsbyuser.innerHTML = data;
                });
            }
            )
            .catch(function (err) {
                console.log('Fetch Error :-S', err);
            });

        return false;
    }
    //
    function doSearch(e) {
        e.preventDefault();
        var url = searchForm.getAttribute("action") + "?search=" + qstring.value;
        //By default felch does GET
        fetch(url, {
            headers: new Headers({
                'Content-Type': 'application/xhtml+xml'
            })
        })
            .then(
            function (response) {
                if (response.status !== 200) {
                    console.log('Looks like there was a problem. Status Code: ' + response.status);
                    return;
                }
                // Examine the response  
                response.text().then(function (data) {
                    retaurants.innerHTML = data;
                });
            }
            )
            .catch(function (err) {
                console.log('Fetch Error :-S', err);
            });

        return false;
    }

    //
    function init() {

        if (searchForm !== null) {
            searchForm.addEventListener("submit", doSearch, false);
        }
        if (reviewSearchForm !== null) {
            reviewSearchForm.addEventListener("submit", getReviews, false);
        }
        $createReview.on("click", "#btnCancel", function () {
            $createReview.hide();
        });
    }
    init();
})();