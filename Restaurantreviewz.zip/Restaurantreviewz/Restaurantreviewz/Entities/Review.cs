﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Restaurantreviewz.Entities
{
    public class Review
    {
        public int ReviewId { get; set; }
        public int RestaurantId { get; set; }

        [Required, MaxLength(100)]
        public string ReviewerName { get; set; }

        [Required, Range(1, 5)]
        public int Rating { get; set; }

        [Required, MaxLength(1024)]
        public string Comment { get; set; }

        public DateTime DateCreated { get; set; }
        public DateTime DateUpdated { get; set; }
    }
}
