﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Restaurantreviewz.Entities
{
    public class Restaurant
    {
        public int RestaurantId { get; set; }

        [Required, MaxLength(250)]
        public string Name { get; set; }

        [MaxLength(250)]
        public string Address { get; set; }

        [Required, MaxLength(50)]
        public string City { get; set; }

        [Required, MaxLength(50)]
        public string State { get; set; }

        [MaxLength(50)]
        public string ZipCode { get; set; }

        [MaxLength(250)]
        public string Website { get; set; }

        [MaxLength(20)]
        public string Phone { get; set; }

        public decimal? AverageRate { get; set; }

        public DateTime DateCreated { get; set; }
        public DateTime DateUpdated { get; set; }
        virtual public ICollection<Review> Reviews { get; set; }
    }
}
