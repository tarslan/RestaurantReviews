﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Restaurantreviewz.Data;
using Restaurantreviewz.Entities;
using Restaurantreviewz.Services;
using Restaurantreviewz.ViewModels.ReviewViewModels;
using Microsoft.AspNetCore.Authorization;
using Restaurantreviewz.ViewModels.RestaurantViewModels;

namespace Restaurantreviewz.Controllers
{
    public class ReviewsController : Controller
    {
        private readonly IRestaurantRepository _repository;

        public ReviewsController(IRestaurantRepository repository)
        {
            _repository = repository;
        }

        // GET: Reviews
        public async Task<IActionResult> Index(int? id)
        {
            if (id == null)
            {
                return View("Notfound");
            }
            var restaurant = await _repository.GetRestaurantWithReviewsAsync((int)id);
            if (restaurant == null)
            {
                return NotFound();
            }
            var model = new RestaurantwitViewsViewModel
            {
                Restaurant = new RestaurantViewModel
                {
                    RestaurantId = restaurant.RestaurantId,
                    Name = restaurant.Name,
                    Website = restaurant.Website,
                    Address = restaurant.Address,
                    City = restaurant.City,
                    State = restaurant.State,
                    ZipCode = restaurant.ZipCode,
                    Phone = restaurant.Phone,
                    AverageRate = (restaurant.AverageRate == null) ? 0 : (int)Math.Round((decimal)restaurant.AverageRate)
                },
                Reviews = restaurant.Reviews.OrderByDescending(r => r.DateCreated).Select(r => new ReviewViewModel
                {
                    ReviewId = r.ReviewId,
                    ReviewerName = r.ReviewerName,
                    Rating = r.Rating,
                    Comment = r.Comment,
                    TimePassed = GetTimeSpan(r.DateCreated),
                }).ToList(),
                NewReview = new AddReviewViewModel
                {
                    RestaurantId = (int)id,
                    Rating = 2,
                    Stars = 2,
                    Comment = string.Empty
                }
            };

            return View(model);
        }


        // GET: Reviews/Create
        [Authorize]
        public IActionResult Addreview(int id)
        {
            //return View();
            //return PartialView("_AddReview", model);
            return RedirectToAction(nameof(Index), new { id = id });
        }
        [HttpPost]
        [Authorize]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Addreview(AddReviewViewModel model)
        {
            if (ModelState.IsValid)
            {
                var review = new Review
                {
                    RestaurantId = model.RestaurantId,
                    Rating = model.Stars,
                    ReviewerName = User.Identity.Name,
                    Comment = model.Comment,
                    DateCreated = DateTime.Now,
                    DateUpdated = DateTime.Now
                };
                _repository.CreateReview(review);
                await _repository.CommitAsync();

                //save stars in Restaurant
                var reviewsPerRestaurant = await _repository.GetReviewsPerRestaurantAsync(model.RestaurantId);
                var average = reviewsPerRestaurant.Average(a => a.Rating);
                    
                var restaurant = await _repository.GetRestaurantAsync(model.RestaurantId);
                restaurant.AverageRate = (decimal)average;
                _repository.UpdateRestaurant(restaurant);


                return RedirectToAction(nameof(Index), new { id = review.RestaurantId });
            }
            
            return View(model);
        }
        private string GetTimeSpan(DateTime givenDate)
        {
            string returnValue = string.Empty;
            TimeSpan interval = DateTime.Now - givenDate;
            string days = (interval.Days > 0) ? interval.Days.ToString() + " days" : string.Empty;
            string hours = (interval.Hours > 0) ? interval.Hours.ToString() + " Hours " : string.Empty;
            string minutes = (interval.Minutes > 0) ? interval.Minutes.ToString() + " Minutes " : string.Empty;
            string seconds = (interval.Seconds > 0) ? interval.Seconds.ToString() + " Seconds" : string.Empty;
            returnValue = days + hours + minutes + seconds;
            if (!string.IsNullOrEmpty(returnValue.Trim()))
            {
                returnValue = returnValue + " ago";
            }
            return returnValue;
        }


        // GET: Reviews/Delete/5
        public IActionResult ByUser()
        {

            return View();
        }
        public async Task<IActionResult> Searchbyuser(string search = null)
        {
            var reviews = await _repository.GetReviewByUserAsync(search);
            var model = reviews.Select(r => new ReviewByUserViewModel
            {
                ReviewId = r.ReviewId,
                Rating = r.Rating,
                ReviewerName = r.ReviewerName,
                Comment = r.Comment,
                TimePassed = GetTimeSpan(r.DateCreated)
            }).ToList();
            return PartialView("_ReviewsByUser", model);
        }

        // POST: Reviews/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int reviewId)
        {
            var review = await _repository.GetReviewAsync(reviewId);

            var rev = _repository.DeleteReview(review);
            await _repository.CommitAsync();
            return RedirectToAction(nameof(Index), new { id = review.RestaurantId });
        }

        private async Task<bool> ReviewExists(int id)
        {
            return await _repository.ReviewExists(id);
        }
    }
}
