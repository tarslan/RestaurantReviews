﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Restaurantreviewz.Data;
using Restaurantreviewz.Entities;
using Restaurantreviewz.Services;
using Restaurantreviewz.ViewModels.RestaurantViewModels;
using Restaurantreviewz.ViewModels.ReviewViewModels;

namespace Restaurantreviewz.Controllers
{
    public class RestaurantsController : Controller
    {
        private readonly IRestaurantRepository _repository;

        public RestaurantsController(IRestaurantRepository repository)
        {
            _repository = repository;
        }

        // GET: Restaurants
        public async Task<IActionResult> Index()
        {
            var restaurants = await _repository.GetAllRestaurantsAsync();
            var model = restaurants.Select(r => new RestaurantViewModel
            {
                RestaurantId = r.RestaurantId,
                Name = r.Name,
                Website = r.Website.Replace("https://", "").Replace("http://", ""),
                Address = r.Address,
                City = r.City,
                State = r.State,
                ZipCode = r.ZipCode,
                Phone = r.Phone,
                AverageRate = (r.AverageRate == null) ?  0: (int)Math.Round((decimal)r.AverageRate)
            });
            return View(model);
        }
        public async Task<IActionResult> Searchbycity(string search = null)
        {
            var restaurants = await _repository.GetRestaurantByCityAsync(search);
            var model = restaurants.Select(r => new RestaurantViewModel
            {
                RestaurantId = r.RestaurantId,
                Name = r.Name,
                Website = r.Website.Replace("https://", "").Replace("http://", ""),
                Address = r.Address,
                City = r.City,
                State = r.State,
                ZipCode = r.ZipCode,
                Phone = r.Phone,
                AverageRate = (r.AverageRate == null) ? 0 : (int)Math.Round((decimal)r.AverageRate)
            });

            return PartialView("_RestaurantsByCity", model);
            //return View(model);
        }

        // GET: Restaurants/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var restaurant = await _repository.GetRestaurantWithReviewsAsync((int)id);
            if (restaurant == null)
            {
                return NotFound();
            }
            var model = new RestaurantwitViewsViewModel
            {
                Restaurant = new RestaurantViewModel
                {
                    RestaurantId = restaurant.RestaurantId,
                    Name = restaurant.Name,
                    Website = restaurant.Website,
                    Address = restaurant.Address,
                    City = restaurant.City,
                    State = restaurant.State,
                    ZipCode = restaurant.ZipCode,
                    Phone = restaurant.Phone,
                    AverageRate = (restaurant.AverageRate == null) ? 0 : (int)Math.Round((decimal)restaurant.AverageRate)
                },
                Reviews = restaurant.Reviews.OrderByDescending(r=> r.DateCreated).Select(r => new ReviewViewModel
                {
                    ReviewId = r.ReviewId,
                    ReviewerName = r.ReviewerName,
                    Rating = r.Rating,
                    Comment = r.Comment,
                    TimePassed = GetTimeSpan(r.DateCreated),
                }).ToList()
            };
            return View(model);
        }
        private string GetTimeSpan(DateTime givenDate)
        {
            string returnValue = string.Empty;
            TimeSpan interval = DateTime.Now - givenDate;
            string days = (interval.Days > 0)? interval.Days.ToString() + " days" : string.Empty;
            string hours = (interval.Hours > 0) ? interval.Hours.ToString() + " Hours " : string.Empty;
            string minutes = (interval.Minutes > 0) ? interval.Minutes.ToString() + " Minutes " : string.Empty;
            string seconds = (interval.Seconds > 0) ? interval.Seconds.ToString() + " Seconds" : string.Empty;
            returnValue = days + hours + minutes + seconds;
            if (!string.IsNullOrEmpty(returnValue.Trim())) {
                returnValue = returnValue + " ago";
             }
            return returnValue;
        }
        // GET: Restaurants/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Restaurants/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("RestaurantId,Name,Address,City,State,ZipCode,Website,Phone")] RestaurantViewModel model)
        {
            if (ModelState.IsValid)
            {
                bool exist = await _repository.RestaurantExists(model.Name, model.City); 
                if (exist)
                {
                    ModelState.AddModelError(" ", "Restaurant: " + model.Name + " already exists in " + model.City);
                }
                else
                {
                    var restaurant = new Restaurant
                    {
                        RestaurantId = model.RestaurantId,
                        Name = model.Name,
                        Website = model.Website,
                        Address = model.Address,
                        City = model.City,
                        State = model.State,
                        ZipCode = model.ZipCode,
                        Phone = model.Phone,
                        DateCreated = DateTime.Now,
                    };
                    _repository.CreateRestaurant(restaurant);
                    await _repository.CommitAsync();
                    return RedirectToAction(nameof(Index));
                }
            }
            return View(model);
        }

        // GET: Restaurants/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var restaurant = await _repository.GetRestaurantAsync((int)id);
            if (restaurant == null)
            {
                return NotFound();
            }
            var model = new RestaurantViewModel
            {
                RestaurantId = restaurant.RestaurantId,
                Name = restaurant.Name,
                Website = restaurant.Website,
                Address = restaurant.Address,
                City = restaurant.City,
                State = restaurant.State,
                ZipCode = restaurant.ZipCode,
                Phone = restaurant.Phone
            };
            return View(model);
        }

        // POST: Restaurants/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("RestaurantId,Name,Address,City,State,ZipCode,Website,Phone")] RestaurantViewModel model)
        {
            if (id != model.RestaurantId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                var restaurant = await _repository.GetRestaurantAsync(model.RestaurantId);
                if (restaurant == null)
                {
                    return NotFound();
                }
                try
                {
                    // AutoMap can be used for mapping entities and ViewModels
                    restaurant.RestaurantId = model.RestaurantId;
                    restaurant.Name = model.Name;
                    restaurant.Website = model.Website;
                    restaurant.Address = model.Address;
                    restaurant.City = model.City;
                    restaurant.State = model.State;
                    restaurant.ZipCode = model.ZipCode;
                    restaurant.Phone = model.Phone;

                    _repository.UpdateRestaurant(restaurant);
                    await _repository.CommitAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    ModelState.AddModelError("", "Data could not be updated. Contact restaurantreviewz.com");
                }
                return RedirectToAction(nameof(Index));
            }
            return View(model);
        }

        // GET: Restaurants/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var restaurant = await _repository.GetRestaurantAsync((int)id);
            if (restaurant == null)
            {
                return NotFound();
            }
            var model = new RestaurantViewModel
            {
                RestaurantId = restaurant.RestaurantId,
                Name = restaurant.Name,
                Website = restaurant.Website,
                Address = restaurant.Address,
                City = restaurant.City,
                State = restaurant.State,
                ZipCode = restaurant.ZipCode,
                Phone = restaurant.Phone
            };
            return View(model);
        }

        // POST: Restaurants/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var restaurant = await _repository.GetRestaurantAsync((int)id);

            await _repository.CommitAsync();
            return RedirectToAction(nameof(Index));
        }

    }
}
