﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Restaurantreviewz.ViewModels.ReviewViewModels
{
    public class AddReviewViewModel
    {
        public int RestaurantId { get; set; }

        [Required, Range(1, 5)]
        public int Rating { get; set; }

        [Required, Range(1, 5)]
        public int Stars { get; set; }

        [Required, MaxLength(1024)]
        public string Comment { get; set; }

    }
}
