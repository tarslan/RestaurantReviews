﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Restaurantreviewz.ViewModels.ReviewViewModels
{
    public class ReviewViewModel
    {
        public int ReviewId { get; set; }

        [Required, MaxLength(100)]
        public string ReviewerName { get; set; }

        [Required, Range(1, 5)]
        public int Rating { get; set; }

        [Required, MaxLength(1024)]
        public string Comment { get; set; }

        public string TimePassed { get; set; }
    }
}
