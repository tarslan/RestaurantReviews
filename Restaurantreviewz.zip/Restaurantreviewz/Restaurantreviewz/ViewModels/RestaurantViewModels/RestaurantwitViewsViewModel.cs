﻿using Restaurantreviewz.ViewModels.ReviewViewModels;
using System.Collections.Generic;

namespace Restaurantreviewz.ViewModels.RestaurantViewModels
{
    public class RestaurantwitViewsViewModel
    {
        public AddReviewViewModel NewReview { get; set; }
        public RestaurantViewModel Restaurant { get; set; }
        public List<ReviewViewModel> Reviews { get; set; }
    }
}
