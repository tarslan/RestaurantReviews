﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Restaurantreviewz.ViewModels.RestaurantViewModels
{
    public class RestaurantViewModel
    {
        public int RestaurantId { get; set; }

        [Required, Display(Name="Restaurant"), MaxLength(250)]
        public string Name { get; set; }

        [MaxLength(250)]
        public string Address { get; set; }

        [Required, MaxLength(50, ErrorMessage = "City name cannot be longer than 50 characters.")]
        public string City { get; set; }

        [Required, MaxLength(50, ErrorMessage = "State name cannot be longer than 50 characters.")]
        public string State { get; set; }

        [Display(Name = "Zip Code"), MaxLength(50)]
        public string ZipCode { get; set; }

        [MaxLength(250)]
        public string Website { get; set; }

        [DataType(DataType.PhoneNumber), MaxLength(20)]
        public string Phone { get; set; }

        public int AverageRate { get; set; }

    }
}
